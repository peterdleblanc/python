
__author__ = 'Peter LeBlanc'

import feedparser
import cx_Oracle
import hashlib
import json
import urllib2
import itertools
import logging
import datetime
import time

from HTMLParser import HTMLParser


logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

## Create a file handler
handler = logging.FileHandler('/opt2/pythonProjects/projects/RSSWebservice/RSS_Webservice.log')
handler.setLevel(logging.DEBUG)
## create a logging format
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
## Add the handler to the logger
logger.addHandler(handler)



class MLStripper(HTMLParser):
    def __init__(self):
        self.reset()
        self.fed = []
    def handle_data(self, d):
        self.fed.append(d)
    def get_data(self):
        return ''.join(self.fed)

def strip_tags(html):
    s = MLStripper()
    s.feed(html)
    return s.get_data()

def get_seq_value(table, seq):
    ### Setup Oracle Connection ####
    dsnStr = cx_Oracle.makedsn('oracle11.compusult.net','1521','devel11')
    con = cx_Oracle.connect(user="RSS_Webservice", password="wes", dsn=dsnStr)

    ### Get report_seq value ###
    cursor = con.cursor()
    sql = "SELECT MAX(" + seq + ") FROM " + table
    cursor.execute(sql)
    results = cursor.fetchall()
    for i in results:
        seq_value = i[0]
    if seq_value == None:
        seq_value = 1

    cursor.close()
    con.close()

    return seq_value

def get_column_names(table):
    ### Setup Oracle Connection ####
    dsnStr = cx_Oracle.makedsn('oracle11.compusult.net','1521','devel11')
    con = cx_Oracle.connect(user="RSS_Webservice", password="wes", dsn=dsnStr)
    cursor = con.cursor()

    #### Get all the column names ####
    sql = "SELECT * FROM " + table
    cursor.execute(sql)
    results = cursor.fetchall()
    cols = {}
    for i in cursor.description:
        k = i[0]
        cols[k] = 'null'

    cursor.close()
    con.close()

    return cols

def write_dict_to_database(table_name, table_dict):

    ### Setup Oracle Connection ####
    dsnStr = cx_Oracle.makedsn('oracle11.compusult.net','1521','devel11')
    con = cx_Oracle.connect(user="RSS_Webservice", password="wes", dsn=dsnStr)
    cursor = con.cursor()

    sql = 'INSERT INTO ' + table_name + '('

    for k,v in table_dict.items():
        if v is not 'null':
            sql = sql + k + ','
    sql = sql[:-1]
    sql = sql + ') VALUES('

    for k,v in table_dict.items():
        if v is not 'null':
            if k is not 'event_time':
                v = str(v)
                if v.isdigit() == True:
                    sql = sql +   v + ","
                if v.isdigit() == False:
                    if k == 'longitude':
                        sql = sql +   v + ","
                    elif k == 'latitude':
                        sql = sql +   v + ","
                    else:
                        sql = sql + "'" + v + "'" + ","
            else:
                sql = sql + "TO_DATE('" + str(v) + "', 'YYYY-MM-DD HH24:MI:SS')" + ","

    sql = sql[:-1]
    sql = sql + ')'

    logger.info(sql)
    cursor.execute(sql)
    sql = "commit"
    cursor.execute(sql)
    cursor.close()
    con.close()


def get_gdacs_hurricane_data():
    ### RSS Feed to harvest ###
    d = feedparser.parse('http://www.gdacs.org/XML/RSS.xml')

    ### Get column names ###
    natural_events = get_column_names('natural_events')
    event_id = get_seq_value('natural_events', 'event_id')

    for post in d.entries:
        desc_text = post.summary
        desc = desc_text.replace("'", "''")
        hashed_desc = hashlib.md5(desc.encode("utf-8"))
        existing_flag = check_for_desc(hashed_desc.hexdigest())
        if existing_flag == 'n':
            event_id = event_id + 1
            natural_events['EVENT_ID'] = event_id
            natural_events['EVENT_TYPE'] = 'HURRICANE'
            natural_events['TITLE'] = post.title
            natural_events['EVENT_DESC'] = desc.encode("utf-8")
            natural_events['LATITUDE'] = post.geo_lat
            natural_events['LONGITUDE'] = post.geo_long
            natural_events['HASHED_DESC'] = hashed_desc.hexdigest()

            write_dict_to_database('natural_events', natural_events)
        else:
            logger.info('Record Exist')


def get_earthquack_data():
    d = feedparser.parse('http://www.bgs.ac.uk/feeds/MhSeismology.xml')

    ### Get column names ###
    natural_events = get_column_names('natural_events')
    event_id = get_seq_value('natural_events', 'event_id')

    for post in d.entries:
        desc_text = post.description
        hashed_desc = hashlib.md5(desc_text)
        existing_flag = check_for_desc(hashed_desc.hexdigest())
        if existing_flag == 'n':
            event_id = event_id + 1
            natural_events['EVENT_ID'] = event_id
            natural_events['EVENT_TYPE'] = 'EARTHQUAKE'
            natural_events['TITLE'] = post.title
            natural_events['EVENT_DESC'] = post.description
            natural_events['LATITUDE'] = post.geo_lat
            natural_events['LONGITUDE'] = post.geo_long
            natural_events['HASHED_DESC'] = hashed_desc.hexdigest()

            write_dict_to_database('natural_events', natural_events)
        else:
            logger.info('Record Exist')



def get_tsunami_data():

    d = feedparser.parse('http://ptwc.weather.gov/feeds/ptwc_rss_pacific.xml')

    ### Get column names ###
    natural_events = get_column_names('natural_events')
    event_id = get_seq_value('natural_events', 'event_id')

    for post in d.entries:
        desc_text = post.description
        desc = desc_text.replace("'", "''")
        hashed_desc = hashlib.md5(desc_text)
        existing_flag = check_for_desc(hashed_desc.hexdigest())
        if existing_flag == 'n':
            event_id = event_id + 1
            natural_events['EVENT_ID'] = event_id
            natural_events['EVENT_TYPE'] = 'TSUNAMI'
            natural_events['TITLE'] = post.title
            natural_events['EVENT_DESC'] = desc.encode("utf-8")
            natural_events['LATITUDE'] = post.geo_lat
            natural_events['LONGITUDE'] = post.geo_long
            natural_events['HASHED_DESC'] = hashed_desc.hexdigest()

            write_dict_to_database('natural_events', natural_events)

        else:
            logger.info('Record Exist')


def get_national_news():
    d = feedparser.parse('http://www.cbc.ca/thenational/blog/atom.xml')


    for post in d.entries:
        desc_text = post.description
        summary_text = post.summary
        summary_notags = strip_tags(summary_text)
        summary_notags = summary_notags.replace("'", "''")
        desc_notags = strip_tags(desc_text)
        desc_notags = desc_notags.replace("'", "''")
        hashed_desc = hashlib.md5(desc_notags.encode("utf-8"))
        #existing_flag = check_for_cable_record(hashed_desc.hexdigest())
        print('***************************************')
        print('title: ' + post.title)
        print('description: ' + desc_notags)
        print('published: ' + post.published)
        print('summary: ' + summary_notags)
        #print(post.content[0].value)

def get_indian_express_news():

    d = feedparser.parse('http://indianexpress.com/section/world/feed/')


    for post in d.entries:
        content = post.content[0]['value']
        content_notags = strip_tags(content)
        content = content_notags.replace("'", "''")
        desc_text = post.description
        desc_notags = strip_tags(desc_text)
        desc_notags = desc_notags.replace("'", "''")
        hashed_desc = hashlib.md5(desc_notags.encode("utf-8"))
        #existing_flag = check_for_cable_record(hashed_desc.hexdigest())
        print('***************************************')
        print('title: ' + post.title)
        print('description: ' + desc_notags)
        print('published: ' + post.published)
        print('content') + content_notags

def generate_geom():
    ### Setup Oracle Connection ####
    dsnStr = cx_Oracle.makedsn('oracle11.compusult.net','1521','devel11')
    con = cx_Oracle.connect(user="RSS_Webservice", password="wes", dsn=dsnStr)
    cursor = con.cursor()
    ### Get report_seq value ###
    cursor = con.cursor()
    sql = "update natural_events set geom = MDSYS.SDO_GEOMETRY(2001, 8307, MDSYS.SDO_POINT_TYPE (latitude,longitude,NULL),NULL,NULL)"
    cursor.execute(sql)
    sql = "commit"
    cursor.execute(sql)

    cursor.close()
    con.close()


def check_for_desc(desc):

    ### Setup Oracle Connection ####
    dsnStr = cx_Oracle.makedsn('oracle11.compusult.net','1521','devel11')
    con = cx_Oracle.connect(user="RSS_Webservice", password="wes", dsn=dsnStr)

    ### Get report_seq value ###
    cursor = con.cursor()
    sql = "SELECT HASHED_DESC FROM NATURAL_EVENTS"
    cursor.execute(sql)
    results = cursor.fetchall()
    existing_flag = 'n'
    for i in results:
        if i[0] == desc:
            existing_flag = 'y'

    cursor.close()
    con.close()

    return existing_flag

def get_usgs_earthQuake_geoJSON_Feed():

    response = urllib2.urlopen('http://earthquake.usgs.gov/fdsnws/event/1/query.geojson?starttime=2015-01-01%2000:00:00&minmagnitude=3&endtime=2015-02-01%2023:59:59&orderby=time')


    logger.info('###############Query Range: 2015-01-01 to  2015-05-01######################################')
    data = json.load(response)
    logger.info('starting json request')
    list_of_events = []
    for x in data['features']:
        for k,v in x['properties'].items():
            #logger.info(k + ': ' + str(v))
            if k == 'detail':
                list_of_events.append(v)
        #eq_record = dict(u.split(':') for u in x.split(','))
    ## reducing list of events

    logger.info('################Getting Event Count#######################')
    count = 0
    for x in list_of_events:
        count = count + 1
    logger.info('Total event count: ' + str(count))

    logger.info('getting details')
    event_record = {}

    seq_id = get_seq_value('USGS_EQ_DATA', 'seq_id')

    for event in list_of_events:
        seq_id = seq_id + 1
        logger.info('')
        logger.info('##################################' + event + '####################################')
        response = urllib2.urlopen(event)
        data = json.load(response)
        event_time = data['properties']['time']
        logger.info(event_time)
        #event_time_conv = time.strftime("%a, %d %b %Y %H:%M:%S +0000", time.gmtime(event_time))
        #event_time_conv = time.strftime("%y-%m-%d %H:%M:%S", datetime.datetime.fromtime(event_time))
        #event_time_conv = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(event_time))
        event_time_conv = datetime.datetime.fromtimestamp(event_time/1000)
        #ts = datetime.datetime.fromtimestamp(event_time).strftime('%Y-%m-%d %H:%M:%S')
        #ts = datetime.datetime.strftime(event_time,'%Y-%m-%d %H:%M:%S')
        #ts = datetime.datetime.strftime(event_time,'%Y-%m-%d %H:%M:%S')

        logger.info(event_time_conv)
        event_record['event_id'] = (data['id'])
        event_record['title'] = (data['properties']['title'].encode('utf-8').replace("'","''"))
        event_record['longitude'] = (data['geometry']['coordinates'][0])
        event_record['latitude'] = (data['geometry']['coordinates'][1])
        event_record['depth'] = (data['geometry']['coordinates'][2])
        event_record['mag'] = (data['properties']['mag'])
        event_record['place'] = (data['properties']['place'].replace("'", "''"))
        #event_record['event_time'] = datetime.datetime(data['properties']['time'])
        event_record['event_time'] = event_time_conv
        #event_record['updated_time'] = (data['properties']['updated'])
        event_record['url'] = (data['properties']['url'])
        event_record['felt'] = (data['properties']['felt'])
        event_record['cdi'] = (data['properties']['cdi'])
        event_record['mmi'] = (data['properties']['mmi'])
        event_record['alert'] = (data['properties']['alert'])
        event_record['status'] = (data['properties']['status'])
        event_record['tsunami'] = (data['properties']['tsunami'])
        event_record['sig'] = (data['properties']['sig'])
        event_record['net'] = (data['properties']['net'])
        event_record['code'] = (data['properties']['code'])
        event_record['ids'] = (data['properties']['ids'])
        event_record['sources'] = (data['properties']['sources'])
        event_record['types'] = (data['properties']['types'])
        event_record['nst'] = (data['properties']['nst'])
        event_record['dmin'] = (data['properties']['dmin'])
        event_record['rms'] = (data['properties']['rms'])
        event_record['gap'] = (data['properties']['gap'])
        event_record['magType'] = (data['properties']['magType'])
        event_record['type'] = (data['properties']['type'])
        event_record['seq_id'] = seq_id
        products = data['properties']['products']

        #logger.info('##########################Listing Product Updates################################')
        #update_count = 0
        #update_record = {}
        #for k,v in products.items():
        #    update_count = update_count + 1
        #    records = v[0]
        #    logger.info('')
        #    logger.info('##################' + records['status'] + ': ' + str(update_count) + '########################################')
        #    logger.info('update time: ' + str(records['updateTime']))
        #    logger.info('')
        #    for k2, v2 in records['properties'].items():
        #        logger.info(k2 + ': ' + str(v2))
        #        update_record[k2] = v2

        #    if 'latitude' in update_record.keys() and 'longitude' in update_record.keys():
        #        logger.info(update_record['eventsourcecode'])
        #        logger.info(update_record['depth'])
        #        logger.info(update_record['latitude'])
        #        logger.info(update_record['longitude'])
        #        logger.info(update_record['magnitude'])

        write_dict_to_database('USGS_EQ_DATA', event_record)

    logger.info('json Population Complete')

def main():

    get_tsunami_data()

    try:
        get_gdacs_hurricane_data()
        pass
    except:
        logger.error('Failed to get Hurricane data')

    try:
        get_earthquack_data()
        pass
    except:
        logger.error('Failed to get Earth Quake data')

    generate_geom()

    logger.info('Start json request')

    #get_usgs_earthQuake_geoJSON_Feed()

    #get_national_news()
    #get_indian_express_news()

    logger.info('Finished Population')


if __name__ == '__main__':
    main()
