
__author__ = 'Peter LeBlanc'

import cx_Oracle
import cherrypy
import json
import datetime
from dateutil import parser
from SOAPpy import WSDL

import logging

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

## Create a file handler
handler = logging.FileHandler('/opt2/pythonProjects/projects/RSSWebservice/web_service.log')
handler.setLevel(logging.INFO)
## create a logging format
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
## Add the handler to the logger
logger.addHandler(handler)

def set_global_oracle_variables():
    ### Setup Global_Oracle Connection ####
    global dsnStr
    dsnStr = cx_Oracle.makedsn('oracle11.compusult.net','1521','devel11')
    global con
    con = cx_Oracle.connect(user="RSS_Webservice", password="wes", dsn=dsnStr)
    global cursor
    cursor = con.cursor()

class StringGenerator(object):
    @cherrypy.expose
    def index(self):
        return """<html>
          <head></head>
          <body>
              <br><h1><b>USGS Earth Quake Data:</b></h1></br>
              <form action="get_eq_by_place_table">
                    Place Name:<br>
                    <input type="text" name="place" value="Japan">
                    <br>
                    <input type="submit" value="get">
              </form>
              <br><b>JSON API</b></br>
              <br>json ojects returns {dictornary:[seq_id][keys][values]</br>
              <br><b>valid endpoints:</b></br>
              <br><b>seq_id</b></br>
              <br>http://peter-l.compusult.net:8080/get_eq_by_seq_id?seq_id=2</br>
              <br><b>Place</b></br>
              <br>http://peter-l.compusult.net:8080/get_eq_by_place?place=Japan</br>
              <br><b>Date Range</b></br>
              <br>http://peter-l.compusult.net:8080/get_eq_by_event_time?begin_date=2015-01-01&end_date=2015-01-02</br>
              <br><b>Event ID</b></br>
              <br>http://peter-l.compusult.net:8080/get_eq_by_event_id?event_id=us20002bwc</br>
              <br></br>
              <br><b>Brower friendly version of the data</b></br>
              <br>http://peter-l.compusult.net:8080/get_eq_by_place_table?place=nepal</br>
              <br>http://peter-l.compusult.net:8080/get_eq_by_event_id_form?event_id=us20002bwc</br>
              <br></br>
              <br>valid date ranges for event_time: 2015-0101 to 2015-05-01</br>
              <br></br>
              <br><h1><b>Natural Events Data:</b></h1></br>
              <br><b>JSON API</b></br>
              <br>json ojects returns {dictornary:[event_id][keys][values]</br>
              <br>valid endpoints:</br>
              <br>http://peter-l.compusult.net:8080/get_event_by_id?event_id=2</br>
              <br>http://peter-l.compusult.net:8080/get_event_by_type?event_type=HURRICANE</br>
              <br><b>Valid Event Types:</b></br>
              <br>HURRICANE</br>
              <br>TSUNAMI</br>
          </body>
        </html>"""

    @cherrypy.expose
    def display(self):
        return cherrypy.session['mystring']

    @cherrypy.expose
    def get_event_by_id(self, event_id):

        requested_fields = ['EVENT_ID','EVENT_DESC', 'EVENT_TYPE', 'TITLE','LATITUDE','LONGITUDE',]

        sql = "SELECT "
        for x in requested_fields:
            sql = sql + x + ','
        sql = sql[:-1]
        sql = sql + " FROM NATURAL_EVENTS "
        sql = sql + " WHERE EVENT_ID = " + event_id

        cursor.execute(sql)
        results = cursor.fetchall()

        response_dict = {}

        response_dict['keys'] = requested_fields

        for x in results:
            response_dict[x[0]] = (x[0], x[1].read(), x[2], x[3], x[4], x[5])

        response = json.dumps(response_dict)

        return response

        cursor.close()
        con.close()

    @cherrypy.expose
    def get_event_by_type(self, event_type):


        requested_fields = ['EVENT_ID', 'EVENT_TYPE', 'TITLE','LATITUDE','LONGITUDE', 'EVENT_DESC']

        sql ="SELECT "
        for x in requested_fields:
            sql = sql + x + ','
        sql = sql[:-1]
        sql = sql + " FROM NATURAL_EVENTS"
        sql = sql + " WHERE EVENT_TYPE = '" + event_type + "'"

        logger.info(sql)
        cursor.execute(sql)
        results = cursor.fetchall()

        response_dict = {}

        response_dict['keys'] = requested_fields

        for x in results:
            response_dict[x[0]] = (x[0], x[1], x[2], x[3], x[4], x[5].read())

        #response = json.dumps(response_dict, sort_keys=True, indent=4, separators=(',', ': '))
        response = json.dumps(response_dict)

        return response

        cursor.close()
        con.close()


    @cherrypy.expose
    def get_eq_by_seq_id(self, seq_id):

        requested_fields = ['event_id', 'title','longitude','latitude','depth','mag','place','url','felt','cdi','mmi','alert','status','tsunami','sig','net','code','ids','sources','types','nst','dmin','rms','gap','magType','type','seq_id','event_time']

        #### Get Data ####
        sql ="SELECT "
        for x in requested_fields:
            sql = sql + x + ','
        sql = sql[:-1]
        sql = sql + " FROM USGS_EQ_DATA"
        sql = sql + " WHERE seq_id = '" + seq_id + "'"

        logger.info(sql)
        cursor.execute(sql)
        results = cursor.fetchall()

        response_dict = {}

        response_dict['keys'] = requested_fields


        for x in results:
            logger.info(x[27])
            response_dict[x[0]] = (x[0], x[1], x[2], x[3], x[4], x[5],x[6], x[7], x[8], x[9], x[10], x[11],x[12], x[13], x[14], x[15], x[16], x[17],x[18], x[19], x[20], x[21], x[22], x[23],x[24], x[25], x[26], x[27].isoformat())

        response = json.dumps(response_dict, sort_keys = True)
        return response

        cursor.close()
        con.close()

    @cherrypy.expose
    def get_eq_by_event_id(self, event_id):

        requested_fields = ['event_id', 'title','longitude','latitude','depth','mag','place','url','felt','cdi','mmi','alert','status','tsunami','sig','net','code','ids','sources','types','nst','dmin','rms','gap','magType','type','seq_id','event_time']

        #### Get Data ####
        sql ="SELECT "
        for x in requested_fields:
            sql = sql + x + ','
        sql = sql[:-1]
        sql = sql + " FROM USGS_EQ_DATA"
        sql = sql + " WHERE event_id = '" + event_id + "'"

        logger.info(sql)
        cursor.execute(sql)
        results = cursor.fetchall()

        response_dict = {}

        response_dict['keys'] = requested_fields


        for x in results:
            response_dict[x[0]] = (x[0], x[1], x[2], x[3], x[4], x[5],x[6], x[7], x[8], x[9], x[10], x[11],x[12], x[13], x[14], x[15], x[16], x[17],x[18], x[19], x[20], x[21], x[22], x[23],x[24], x[25], x[26], x[27].isoformat())

        response = json.dumps(response_dict, sort_keys = True)

        return response

        cursor.close()
        con.close()

    @cherrypy.expose
    def get_eq_by_place(self, place):

        requested_fields = ['event_id', 'title','longitude','latitude','depth','mag','place','url','felt','cdi','mmi','alert','status','tsunami','sig','net','code','ids','sources','types','nst','dmin','rms','gap','magType','type','seq_id','event_time']

        sql ="SELECT "
        for x in requested_fields:
            sql = sql + x + ','
        sql = sql[:-1]
        sql = sql + " FROM USGS_EQ_DATA"
        sql = sql + " WHERE Upper(place) like '%" + place.upper() + "%'"

        logger.info(sql)
        cursor.execute(sql)
        results = cursor.fetchall()

        response_dict = {}

        response_dict['keys'] = requested_fields

        for x in results:

            response_dict[x[0]] = (x[0], x[1], x[2], x[3], x[4], x[5],x[6], x[7], x[8], x[9], x[10], x[11],x[12], x[13], x[14], x[15], x[16], x[17],x[18], x[19], x[20], x[21], x[22], x[23],x[24], x[25], x[26],x[27].isoformat())

        response = json.dumps(response_dict, sort_keys = True)

        return response

        cursor.close()
        con.close()

    @cherrypy.expose
    def get_eq_by_event_time(self, begin_date, end_date):

        cursor.execute(
            "ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD HH24:MI:SS'"
            " NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH24:MI:SS.FF'")


        requested_fields = ['event_id', 'title','longitude','latitude','depth','mag','place','url','felt','cdi','mmi','alert','status','tsunami','sig','net','code','ids','sources','types','nst','dmin','rms','gap','magType','type','seq_id','event_time']


        sql ="SELECT "
        for x in requested_fields:
            sql = sql + x + ','
        sql = sql[:-1]
        sql = sql + " FROM USGS_EQ_DATA"
        sql = sql + " WHERE event_time > '" + str(parser.parse(begin_date)) + "' AND event_time < '" + str(parser.parse(end_date)) + "'"

        logger.info(sql)

        cursor.execute(sql)
        results = cursor.fetchall()

        response_dict = {}

        response_dict['keys'] = requested_fields

        for x in results:

            response_dict[x[0]] = (x[0], x[1], x[2], x[3], x[4], x[5],x[6], x[7], x[8], x[9], x[10], x[11],x[12], x[13], x[14], x[15], x[16], x[17],x[18], x[19], x[20], x[21], x[22], x[23],x[24], x[25], x[26],x[27].isoformat())

        response = json.dumps(response_dict, sort_keys = True)

        return response

        cursor.close()
        con.close()

    @cherrypy.expose
    def USGS(self):
        return """<html>
          <head>USGS Earthquake Data</head>
          <body>
               <form action="get_eq_by_place_table">
                    Place Name:<br>
                    <input type="text" name="place" value="Japan">
                    <br>
                    <br><br>
                    <input type="submit" value="get">
               </form>
          </body>
        </html>"""

    @cherrypy.expose
    def get_eq_by_place_table(self, place):

        requested_fields = ['event_id', 'title','longitude','latitude','depth','mag','place','alert','status','tsunami','event_time']

        sql ="SELECT "
        for x in requested_fields:
            sql = sql + x + ','
        sql = sql[:-1]
        sql = sql + " FROM USGS_EQ_DATA"
        sql = sql + " WHERE Upper(place) like '%" + place.upper() + "%'"

        logger.info(sql)
        cursor.execute(sql)
        results = cursor.fetchall()

        response_dict = {}

        response_dict['keys'] = requested_fields

        for x in results:
            response_dict[x[0]] = (x[0], x[1], x[2], x[3], x[4], x[5],x[6], x[7], x[8], x[9], x[10].isoformat())

        table_response = '<html><head>Results for place name: ' + place + '<head><body>'
        table_response =  table_response + '<table border="1" style="width:100%">'
        table_response = table_response + '<tr>'
        for x in requested_fields:
            table_response = table_response + '<th><b>'+ x + '</b></th>'
        for k,v in response_dict.items():
            if k is not 'keys':
                table_response = table_response + '<tr>'
                for i in range(len(v)):
                    if requested_fields[i] == 'event_id':
                        table_response = table_response + '<td> <a href="http://peter-l.compusult.net:8080/get_eq_by_event_id_form?event_id='+ v[i] + '">' + str(v[i]) + '</a></td>'
                    else:
                        table_response = table_response + '<td>' + str(v[i]) + '</td>'
                table_response = table_response + '</tr>'
        table_response = table_response + '</table>'
        table_response = table_response + '</body></html>'


        return table_response

        cursor.close()
        con.close()

    @cherrypy.expose
    def get_eq_by_event_id_form(self, event_id):

        requested_fields = ['event_id', 'title','longitude','latitude','depth','mag','place','url','felt','cdi','mmi','alert','status','tsunami','sig','net','code','ids','sources','types','nst','dmin','rms','gap','magType','type','seq_id','event_time']

        #### Get Data ####
        sql ="SELECT "
        for x in requested_fields:
            sql = sql + x + ','
        sql = sql[:-1]
        sql = sql + " FROM USGS_EQ_DATA"
        sql = sql + " WHERE event_id = '" + event_id + "'"

        logger.info(sql)
        cursor.execute(sql)
        results = cursor.fetchall()

        response_dict = {}

        response_dict['keys'] = requested_fields


        for x in results:
            response_dict[x[0]] = (x[0], x[1], x[2], x[3], x[4], x[5],x[6], x[7], x[8], x[9], x[10], x[11],x[12], x[13], x[14], x[15], x[16], x[17],x[18], x[19], x[20], x[21], x[22], x[23],x[24], x[25], x[26], x[27].isoformat())

        form_response = '<html><head><b>Results for event id: </b>' + event_id + '<head><body>'
        form_response = form_response + '<table style="width:90%">'
        form_response = form_response + '<br></br>'
        for k,v in response_dict.items():
            count = 0
            if k is not 'keys':
                for i in xrange(len(requested_fields)):
                    form_response = form_response + '<tr>'
                    if requested_fields[i] == 'url':
                        form_response = form_response + '<td><b>' + requested_fields[i] + ':</b></td>' + '<td><a href=' + str(v[i]) + '>' + str(v[i]) + '</a></td>'
                        pass
                    else:
                        form_response = form_response + '<td><b>' + requested_fields[i] + ':</b></td>' + '<td>' + str(v[i]) + '</td>'
                    form_response = form_response + '</tr>'
        form_response = form_response + '</table>'


        form_response = form_response + '</body></html>'

        return form_response

        cursor.close()
        con.close()

if __name__ == '__main__':
    set_global_oracle_variables()
    conf = {
         '/': {
             'tools.sessions.on': True
         }
     }
    cherrypy.config.update({'server.socket_host': '0.0.0.0'})
    cherrypy.quickstart(StringGenerator(), '/', conf)