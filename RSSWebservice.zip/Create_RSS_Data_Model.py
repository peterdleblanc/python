__author__ = 'Peter LeBlanc'

import feedparser
import cx_Oracle


def create_empty_user():
    ### Setup Oracle Connection ####
    dsnStr = cx_Oracle.makedsn('oracle11.compusult.net','1521','devel11')
    con = cx_Oracle.connect(user="system", password="sage", dsn=dsnStr)
    cursor = con.cursor()
    commit_sql = 'commit'

    sql = "create user RSS_Webservice identified by wes default tablespace WESDATA"
    cursor.execute(sql)
    cursor.execute(commit_sql)
    sql = "grant connect, resource, create session, create table, create synonym, create view, create sequence, create job, ctxapp to RSS_Webservice"
    cursor.execute(sql)
    cursor.execute(commit_sql)
    cursor.close()
    con.close()

def create_tables():
    ### Setup Oracle Connection ####
    dsnStr = cx_Oracle.makedsn('oracle11.compusult.net','1521','devel11')
    con = cx_Oracle.connect(user="RSS_Webservice", password="wes", dsn=dsnStr)
    cursor = con.cursor()
    commit_sql = 'commit'

    sql = 'CREATE TABLE natural_events( ' \
          'event_id    NUMBER(10),' \
          'event_type    VARCHAR2(50),' \
          'title       VARCHAR2(250),' \
          'country       VARCHAR2(75),' \
          'event_type       VARCHAR2(50),' \
          'alert_level       VARCHAR2(50),' \
          'severity       VARCHAR2(50),' \
          'population       NUMBER(10),' \
          'event_desc  CLOB,' \
          'latitude    FLOAT(5),' \
          'longitude   FLOAT(5),' \
          'hashed_desc  VARCHAR2(250),' \
          'geom        MDSYS.SDO_GEOMETRY,' \
          'harvest_date    DATE    DEFAULT SYSDATE),' \
          'published_date    DATE)'

    print(sql)
    cursor.execute(sql)
    cursor.execute(commit_sql)

    cursor.close()
    con.close()

def create_usgs_tables():
    ### Setup Oracle Connection ####
    dsnStr = cx_Oracle.makedsn('oracle11.compusult.net','1521','devel11')
    con = cx_Oracle.connect(user="RSS_Webservice", password="wes", dsn=dsnStr)
    cursor = con.cursor()
    commit_sql = 'commit'


    sql = 'CREATE TABLE usgs_eq_data( ' \
          'event_id       VARCHAR2(50),' \
          'title    VARCHAR2(250),' \
          'longitude FLOAT(5),' \
          'latitude  FLOAT(5),' \
          'depth     FLOAT(1),' \
          'mag      FLOAT(1),' \
          'place   VARCHAR2(250),' \
          'event_time     DATE,' \
          'updated_time  DATE,' \
          'url      VARCHAR(75),' \
          'felt    VARCHAR(50),' \
          'cdi     VARCHAR(50),' \
          'mmi     VARCHAR(50),' \
          'alert    VARCHAR(50),' \
          'status   VARCHAR(50),' \
          'tsunami  VARCHAR(50),' \
          'sig      VARCHAR(50),' \
          'net      VARCHAR(50),' \
          'code     VARCHAR(50),' \
          'ids      VARCHAR(100),' \
          'sources  VARCHAR(50),' \
          'types    VARCHAR(250),' \
          'nst      VARCHAR(50),' \
          'dmin     VARCHAR(50),' \
          'rms      VARCHAR(50),' \
          'gap      VARCHAR(50),' \
          'magType  VARCHAR(50),' \
          'type     VARCHAR(50),' \
          'harvest_date  DATE, ' \
          'geom        MDSYS.SDO_GEOMETRY,' \
          'seq_id   NUMBER(38),' \
          'CONSTRAINT  usgs_seq_pk  PRIMARY KEY (seq_id)' \
          ')'

    print(sql)
    cursor.execute(sql)
    cursor.execute(commit_sql)
    cursor.close()
    con.close()


def main():
    #create_empty_user()
    #create_tables()
    create_usgs_tables()

    print('User Created')

if __name__ == '__main__':
    main()

