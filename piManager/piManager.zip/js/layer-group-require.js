goog.require('ol.Map');
goog.require('ol.View');
goog.require('ol.dom.Input');
goog.require('ol.layer.Group');
goog.require('ol.layer.Tile');
goog.require('ol.proj');
goog.require('ol.source.MapQuest');
goog.require('ol.source.TileJSON');
