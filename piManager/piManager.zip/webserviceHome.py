__author__ = 'Peter LeBlanc'

import cherrypy
import serialTesting
import pyfirmata
import midiMonitor

try:
    port = '/dev/ttyACM0'
except:
    port = '/dev/ttyACM1'
print('Setting up Serial connection to the Arduino')
board = pyfirmata.Arduino(port)
ledPin4 = board.get_pin('d:4:o')


class Home(object):
    @cherrypy.expose
    def index(self):
        return """
        <html>
            <head><title>Demo Site</title>
            <link href="./css/home.css" rel="stylesheet">
            </head>
            <nav id="nav01"></nav>
            <body>
                <div id="main">
                <h1>Welcome to Peter's Demo Site</h1>
                <h2>Web Site Main Components :</h2>

                <form action="toggleOnPIN4" method="post">
                    <button onclick="toggleOnPIN4">PIN4 On</button>
                </form>
            </body>

        </html>"""

    @cherrypy.expose
    def toggleOnPIN4(self):
        print('Updating pin to on')
        ledPin4.write(1)
        return """
        <html>
            <head><title>Demo Site</title>
            <link href="./css/home.css" rel="stylesheet">
            </head>
            <nav id="nav01"></nav>
            <body>
                <div id="main">
                <h1>Welcome to Peter's Demo Site</h1>
                <h2>Web Site Main Components :</h2>

                <form action="toggleOffPIN4" method="post">
                    <button onclick="toggleOffPIN4">PIN4 Off</button>
                </form>
            </body>

        </html>"""

    @cherrypy.expose
    def toggleOffPIN4(self):
        print('Updating pin to off')
        ledPin4.write(0)
        return """
        <html>
            <head><title>Demo Site</title>
            <link href="./css/home.css" rel="stylesheet">
            </head>
            <nav id="nav01"></nav>
            <body>
                <div id="main">
                <h1>Welcome to Peter's Demo Site</h1>
                <h2>Web Site Main Components :</h2>

                <form action="toggleOnPIN4" method="post">
                    <button onclick="toggleOnPIN4">PIN4 On</button>
                </form>
            </body>

        </html>"""

