__author__ = 'Peter LeBlanc'

from time import sleep
from pyfirmata import util
import pyfirmata

try:
    port = '/dev/ttyACM0'
except:
    port = '/dev/ttyACM1'

print('Setting up Serial connection to the Arduino')
board = pyfirmata.Arduino(port)
ledPin4 = board.get_pin('d:4:o')
ledPin8 = board.get_pin('d:8:i')

def readDueSerial():
    while True:
        #counter = 0 # Below 32 everything in ASCII is gibberish
        #counter +=1
        #msg = counter
        #ser.write(msg) # Convert the decimal number to ASCII then send it to the Arduino
        in_msg = ser.readline()
        msg_str = in_msg.decode(encoding='UTF-8')
        print(msg_str) # Read the newest output from the Arduino
        sleep(.1) # Delay for one tenth of a second

def blinkLED(pin, delay, message):

    board = pyfirmata.Arduino(port)
    while True:
        print(message)
        board.digital[pin].write(1)
        sleep(delay)
        board.digital[pin].write(0)
        sleep(delay)

def get_pin_state(pin):

    board = pyfirmata.Arduino(port)
    sleep(3)
    ledPin = board.get_pin('d:8:o')
    state = ledPin.read()
    return state


def toggleOffPIN4():
    print('Updating pin to off')
    ledPin4.write(0)


def toggleOnPIN4():
    print('Updating pin to on')
    ledPin4.write(1)

def readPin9():
    it = util.Iterator(board)
    it.start()
    board.analog[0].enable_reporting()
    print(board.analog[0].read())
    #it.start()

def readPin8():
    #state = ledPin4.read()
    state = board.digital[8].read()
    print(state)
    return state

def main():
    pass
    #toggleOffPIN4()
    #pin = 12
    #delay = 2
    #message = 'cycle complete'
    #blinkLED(pin, delay, message)

if __name__ == '__main__':
    main()

