__author__ = 'Peter LeBlanc'

import cherrypy
import logging

class Home(object):

    def __init__(self):
        self.name = 'homeWebservice'

    @cherrypy.expose
    def index(self):
        return """
        <html>
            <head><title>Demo Site</title>
            <link href="./css/home.css" rel="stylesheet">
            </head>
            <nav id="nav01"></nav>
            <body>
                <div id="main">
                <h1>Welcome to Peter's Demo Site</h1>
                <h2>Web Site Main Components :</h2>

                <p>Geospatial Map Hosting Service (Geoserver)</p>
                <p>Geospatial Client Service (Open Layers)</p>
                <p>RSS Feed Harvesting and Searching (Python / Solr / Cassandra)</p>
                <p>JSON Services (Python)</p>
                <p>REST Services (Python)</p>
                <p>Satellite Data Visualization </p>
                </div>
            <script src="./js/script.js"></script>

            </body>

        </html>"""



if __name__ == '__main__':
    cherrypy.config.update('/opt2/pythonDevelopment/projects/piManager/global.conf')
    cherrypy.tree.mount(Home(), "/","config.conf")

    cherrypy.engine.start()
    cherrypy.engine.block()


