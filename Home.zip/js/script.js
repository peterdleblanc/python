document.getElementById("nav01").innerHTML =
"<ul id='menu'>" +
"<li><a href='index'>Home</a></li>" +
"<li><a href='DataSets'>Datasets</a></li>" +
"<li><a href='eq_data_home'>EQ Search Form</a></li>" +
"<li><a href='NaturalDisastersHome'>Natural Disasters</a></li>" +
"<li><a href='DiseaseOutbreakHome'>Disease Outbreak News</a></li>" +
"<li><a href='NewsSourcesHome'>World News</a></li>" +
"<li><a href='displayMap'>Maps</a></li>" +
"<li><a href='about'>About</a></li>" +
"</ul>";

